# React Ethereal #

This is not a framework, is an structure for ReactJs based on redux and another components.
