/* initial state */
export default {
  list: []
}
