/* Chat */
export const LOAD_CHAT_SUCCESS = 'LOAD_CHAT_SUCCESS';


/* Session */
export const AUTH_SUCCESS = 'AUTH_SUCCESS';
export const AUTH_FAIL = 'AUTH_FAIL';
